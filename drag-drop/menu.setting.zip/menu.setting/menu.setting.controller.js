ucAdmin.ngModule.controller('MenuSettingController', ['$scope', 'dialog', 'AuthInfo', 'ErrorCode', 'SiteService', 'AppService',
    function ($scope, dialog, AuthInfo, ErrorCode, SiteService, AppService) {
        $scope.pcMenuList = {
            allowType: 'pc',
            mainMenu: []
        };
        $scope.mobileMenuList = {
            allowType: 'mobile',
            mainMenu: []
        };
        $scope.authInfo = AuthInfo.getAuthInfo();
        $scope.siteId = $scope.authInfo ? $scope.authInfo.site.siteId : 0;

        var param = {
            siteId: $scope.siteId
        };

        window.pcMenuList = $scope.pcMenuList;

        SiteService.getClientMenu(param).then(function(res){
            if(res.data && res.data.errorCode == ErrorCode.SUCCESS){
                var data = res.data.data;
                console.log('init list', data);

                $scope.pcMenuList.mainMenu = data.pc;
                $scope.mobileMenuList.mainMenu = data.mobile;
            }
        });

        $scope.getDefaultList = function(type){
            var param = {
                siteId: $scope.siteId,
                isDefault: true
            };

            SiteService.getClientMenu(param).then(function(res){
                if(res.data && res.data.errorCode == ErrorCode.SUCCESS){
                    var data = res.data.data;
                    console.log('default list', data);

                    if(type == 'pc'){
                        $scope.pcMenuList.mainMenu = data.pc;
                    }else if(type == 'mobile'){
                        $scope.mobileMenuList.mainMenu = data.mobile;
                    }
                }
            });
        };

        $scope.save = function(){
            var param = {
                "pc": $scope.pcMenuList.mainMenu,
                "mobile": $scope.mobileMenuList.mainMenu
            };

            SiteService.setClientMenu(param).then(function(res){
                if(res.data && res.data.errorCode == ErrorCode.SUCCESS){
                    console.log('save list');

                    dialog.tips('导航设置成功', 'success');
                }else {
                    dialog.tips('导航设置成功失败', 'danger');
                }
            });
        };

        $scope.setItemDragging = function(list, item, allowType, parentIndex){
            console.log('setItemDragging', item);

            angular.forEach(list.mainMenu, function(item) {
                item.selected = false;
                item.allowType = null;

                if(item.children.length > 0){
                    angular.forEach(item.children, function(subItem) {
                        subItem.selected = false;
                        subItem.allowType = null;
                        item.parentIndex = null;
                    });
                }
            });

            item.selected = true;
            item.allowType = allowType;

            if(item.level == 2){
                item.parentIndex = parentIndex;
                return list.children.filter(function(item){
                    return item.selected;
                });
            }

            return list.mainMenu.filter(function(item){
                return item.selected;
            });
        };

        $scope.onDropInMainMenu = function(list, draggingItems, dIndex){
            console.log('onDropInMainMenu');
            console.log('list', list);
            console.log('draggingItems', draggingItems);
            console.log('dIndex', dIndex);

            if(draggingItems[0].allowType != list.allowType){
                console.log("外部元素禁止插入");
                return false;
            }

            if(list.mainMenu.length == 2 && draggingItems[0].level == 1){
                // dialog.tips('一级导航最少为2个', 'danger');
                angular.forEach(list.mainMenu, function(item) {
                    item.selected = false;
                    item.allowType = null;
                });
                return false;
            }

            if(draggingItems[0].level == 1 && draggingItems[0].children.length > 0){
                if(dIndex == -1 || dIndex > list.mainMenu.length){// 办公放在了一级导航外面
                    console.log('办公放在了一级导航外面');
                    angular.forEach(list.mainMenu, function(item) {
                        item.selected = false;
                        item.allowType = null;
                    });
                    return false;
                }else{
                    for(var i in list.mainMenu){
                        if(list.mainMenu[i].id == draggingItems[0].id){// 办公放在了办公自身上
                            if(i == dIndex){
                                console.log('办公放在了办公自身上');
                                angular.forEach(list.mainMenu, function(item) {
                                    item.selected = false;
                                    item.allowType = null;
                                });
                                return false;
                            }

                        }
                    }
                }
            }

            if(draggingItems[0].type == 'customApp'){
                dialog.tips('自定义模块不能设为一级导航', 'danger');
                if(draggingItems[0].level == 1){
                    angular.forEach(list.mainMenu, function(item) {
                        item.selected = false;
                        item.allowType = null;
                    });
                }else if(draggingItems[0].level == 2){
                    angular.forEach(list.mainMenu[draggingItems[0].parentIndex].children, function(item) {
                        item.selected = false;
                        item.allowType = null;
                        item.parentIndex = null;
                    });
                }
                return false;
            }

            if(draggingItems[0].allowType == 'pc' && list.mainMenu.length == 6 && draggingItems[0].level == 2){
                dialog.tips('PC端一级导航最多为6个', 'danger');
                if(draggingItems[0].level == 1){
                    angular.forEach(list.mainMenu, function(item) {
                        item.selected = false;
                        item.allowType = null;
                    });
                }else if(draggingItems[0].level == 2){
                    angular.forEach(list.mainMenu[draggingItems[0].parentIndex].children, function(item) {
                        item.selected = false;
                        item.allowType = null;
                        item.parentIndex = null;
                    });
                }
                return false;
            }

            if(draggingItems[0].allowType == 'mobile' && list.mainMenu.length == 5 && draggingItems[0].level == 2){
                dialog.tips('移动端一级导航最多为5个', 'danger');
                if(draggingItems[0].level == 1){
                    angular.forEach(list.mainMenu, function(item) {
                        item.selected = false;
                        item.allowType = null;
                    });
                }else if(draggingItems[0].level == 2){
                    angular.forEach(list.mainMenu[draggingItems[0].parentIndex].children, function(item) {
                        item.selected = false;
                        item.allowType = null;
                        item.parentIndex = null;
                    });
                }
                return false;
            }

            angular.forEach(draggingItems, function(item) { item.selected = false; });
            list.mainMenu = list.mainMenu.slice(0, dIndex)
                .concat(draggingItems)
                .concat(list.mainMenu.slice(dIndex));

            angular.forEach(list.mainMenu, function(item) { item.level = 1; });

            return true;
        };

        $scope.onMainMenuItemMoved = function(list){
            console.log('onMainMenuItemMoved');

            list.mainMenu = list.mainMenu.filter(function(item){
                return !item.selected;
            });
        };

        $scope.onDropInSubMenu = function(totalList, list, draggingItems, dIndex, parentIndex){
            console.log('onDropInSubMenu');
            console.log('list', list);
            console.log('draggingItems', draggingItems);
            console.log('dIndex', dIndex);
            console.log('parentIndex', parentIndex);

            if(draggingItems[0].allowType != totalList.allowType){
                console.log("外部元素禁止插入");
                return false;
            }

            if(totalList.mainMenu.length == 2 && draggingItems[0].level == 1){
                dialog.tips('一级导航最少为2个', 'danger');
                angular.forEach(totalList.mainMenu, function(item) {
                    item.selected = false;
                    item.allowType = null;
                });
                return false;
            }

            if(draggingItems[0].level == 1 && draggingItems[0].children.length > 0){
                console.log("办公禁止插入到二级导航");
                angular.forEach(totalList.mainMenu, function(item) {
                    item.selected = false;
                    item.allowType = null;
                });
                return false;
            }

            angular.forEach(draggingItems, function(item) { item.selected = false; });
            list[parentIndex].children = list[parentIndex].children.slice(0, dIndex)
                .concat(draggingItems)
                .concat(list[parentIndex].children.slice(dIndex));

            angular.forEach(list[parentIndex].children, function(item) { item.level = 2; });

            return true;
        };

        $scope.onSubMenuItemMoved = function(list){
            console.log('onSubMenuItemMoved');

            var parentIndex = -1;
            for(var i in list.mainMenu){
                if(list.mainMenu[i].children.length > 0){
                    parentIndex = i;
                    break;
                }
            }

            if(parentIndex > -1){
                list.mainMenu[parentIndex].children = list.mainMenu[parentIndex].children.filter(function(item){
                    return !item.selected;
                });
            }
        };
    }
]);